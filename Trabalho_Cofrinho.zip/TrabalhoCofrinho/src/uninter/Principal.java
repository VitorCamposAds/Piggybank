package uninter;

public class Principal {

    public static void main(String[] args) {

        // Cria uma instância da classe Menu para gerenciar as interações do usuário
        Menu menu = new Menu();

        // Exibe o menu principal e inicia o programa
        menu.exibirMenuPrincipal();
    }
}
