package uninter;

import java.util.ArrayList;

public class Cofrinho {

    // ArrayList para armazenar as moedas no cofrinho
    private ArrayList<Moeda> listaMoedas;

    // Construtor da classe Cofrinho
    public Cofrinho() {
        // Inicializa o ArrayList de moedas vazio
        this.listaMoedas = new ArrayList<>();
    }

    // Método para adicionar uma moeda ao cofrinho
    public void adicionar(Moeda moeda) {
        this.listaMoedas.add(moeda);
    }

    // Método para remover uma moeda do cofrinho
    public boolean remover(Moeda moeda) {
        // Remove a moeda da lista e retorna true se a remoção foi bem-sucedida
        return this.listaMoedas.remove(moeda);
    }

    // Método para listar todas as moedas do cofrinho
    public void listagemMoedas() {
        // Verifica se o cofrinho está vazio
        if (this.listaMoedas.isEmpty()) {
            // Se estiver vazio, imprime uma mensagem informando que não há moedas
            System.out.println("Não existe nenhuma moeda no cofrinho.");
            return;
            // Guard Cause ou Early Return: interrompe a execução do método após a mensagem ser impressa
        }

        // Percorre a lista de moedas e chama o método info() para cada uma
        for (Moeda moeda : this.listaMoedas) {
            moeda.info();
        }
    }

    // Método para calcular o valor total das moedas convertido para Real
    public double totalConvertido() {
        // Verifica se o cofrinho está vazio
        if (this.listaMoedas.isEmpty()) {
            // Se estiver vazio, retorna o valor 0, pois não há moedas para converter
            return 0;
        }

        // Variável para acumular o valor total das moedas convertido para Real
        double valorAcumulado = 0;
        // Percorre a lista de moedas e adiciona o valor de cada moeda convertido para Real ao valorAcumulado
        for (Moeda moeda : this.listaMoedas) {
            valorAcumulado = valorAcumulado + moeda.converter();
        }

        // Retorna o valor total acumulado das moedas convertido para Real
        return valorAcumulado;
    }

}
