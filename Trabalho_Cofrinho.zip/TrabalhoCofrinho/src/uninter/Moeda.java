package uninter;

public abstract class Moeda {
	
	// Atributo que armazena o valor da moeda
	protected double valor;
	 
	// Método abstrato para exibir informações sobre a moeda
	public abstract void info();
	 
	// Método abstrato para converter o valor da moeda para Real
	public abstract double converter();
	
}
