package uninter;
import java.util.Scanner;

public class Menu {

    private Scanner sc;
    private Cofrinho cofrinho;

    // Construtor da classe Menu
    public Menu() {
        // Inicializa o Scanner para leitura de entrada do usuário
        sc = new Scanner(System.in);
        // Cria uma instância da classe Cofrinho para gerenciar as moedas
        cofrinho = new Cofrinho();
    }

    // Método para exibir o menu principal
    public void exibirMenuPrincipal() {
        System.out.println("Cofrinho:");
        System.out.println("1-Adicionar Moeda");
        System.out.println("2-Remover moeda");
        System.out.println("3-Listar moedas");
        System.out.println("4-Calcular valor convertido para real");
        System.out.println("0-Encerrar:");

        // Lê a opção selecionada pelo usuário
        String opcaoSelecionada = sc.next();

        // Executa a ação correspondente à opção selecionada pelo usuário
        switch (opcaoSelecionada) {
            case "0":
                System.out.println("Sistema encerrado!");
                break;

            case "1":
                // Exibe o sub menu para adicionar moedas
                exibirSubMenuAdicionarMoedas();
                // Volta a exibir o menu principal após adicionar a moeda
                exibirMenuPrincipal();
                break;

            case "2":
                // Exibe o sub menu para remover moedas
                exibirSubMenuRemoverMoedas();
                // Volta a exibir o menu principal após remover a moeda
                exibirMenuPrincipal();
                break;

            case "3":
                // Lista todas as moedas do cofrinho
                cofrinho.listagemMoedas();
                // Volta a exibir o menu principal após listar as moedas
                exibirMenuPrincipal();
                break;

            case "4":
                // Calcula o valor total convertido das moedas para Real
                double valorTotalConvertido = cofrinho.totalConvertido();
                // Formata o valor para exibir com duas casas decimais e substitui o separador decimal por vírgula
                String valorTotalConvertidoTextual = String.format("%.2f", valorTotalConvertido);
                valorTotalConvertidoTextual = valorTotalConvertidoTextual.replace(".", ",");
                System.out.println("O valor convertido para Real é: R$ " + valorTotalConvertidoTextual + ".");
                // Volta a exibir o menu principal após realizar o cálculo
                exibirMenuPrincipal();
                break;

            default:
                System.out.println("Opção Inválida!");
                // Volta a exibir o menu principal caso a opção seja inválida
                exibirMenuPrincipal();
                break;
        }
    }

    // Método para exibir o sub menu de adicionar moedas
    private void exibirSubMenuAdicionarMoedas() {
        System.out.println("Escolha a sua moeda:");
        System.out.println("1 - Real");
        System.out.println("2 - Dolar");
        System.out.println("3 - Euro");

        // Lê a opção de moeda selecionada pelo usuário
        int opcaoMoeda = sc.nextInt();

        System.out.println("Digite o valor: ");
        // Lê o valor da moeda digitado pelo usuário
        String valorTextualMoeda = sc.next();

        // Substitui o separador decimal por ponto e converte o valor textual para um valor numérico
        valorTextualMoeda = valorTextualMoeda.replace(",", ".");
        double valorMoeda = Double.parseDouble(valorTextualMoeda);

        Moeda moeda = null;

        // Cria uma instância da moeda correspondente à opção selecionada pelo usuário
        if (opcaoMoeda == 1) {
            moeda = new Real(valorMoeda);
        } else if (opcaoMoeda == 2) {
            moeda = new Dolar(valorMoeda);
        } else if (opcaoMoeda == 3) {
            moeda = new Euro(valorMoeda);
        } else {
            System.out.println("Não existe esta opção!");
            // Volta a exibir o menu principal caso a opção seja inválida
            exibirMenuPrincipal();
        }

        // Adiciona a moeda ao cofrinho e exibe uma mensagem de sucesso
        cofrinho.adicionar(moeda);
        System.out.println("Moeda adicionada!");
    }

    // Método para exibir o sub menu de remover moedas
    private void exibirSubMenuRemoverMoedas() {
        System.out.println("Escolha a sua moeda:");
        System.out.println("1 - Real");
        System.out.println("2 - Dolar");
        System.out.println("3 - Euro");

        // Lê a opção de moeda selecionada pelo usuário
        int opcaoMoeda = sc.nextInt();

        System.out.println("Digite o valor: ");
        // Lê o valor da moeda digitado pelo usuário
        String valorTextualMoeda = sc.next();

        // Substitui o separador decimal por ponto e converte o valor textual para um valor numérico
        valorTextualMoeda = valorTextualMoeda.replace(",", ".");
        double valorMoeda = Double.parseDouble(valorTextualMoeda);

        Moeda moeda = null;

        // Cria uma instância da moeda correspondente à opção selecionada pelo usuário
        if (opcaoMoeda == 1) {
            moeda = new Real(valorMoeda);
        } else if (opcaoMoeda == 2) {
            moeda = new Dolar(valorMoeda);
        } else if (opcaoMoeda == 3) {
            moeda = new Euro(valorMoeda);
        } else {
            System.out.println("Não existe esta opção!");
            // Volta a exibir o menu principal caso a opção seja inválida
            exibirMenuPrincipal();
        }

        // Remove a moeda do cofrinho e exibe uma mensagem de sucesso ou falha
        boolean removeuMoeda = cofrinho.remover(moeda);

        if (removeuMoeda) {
            System.out.println("A opção de remover moeda foi executada com sucesso!");
        } else {
            System.out.println("A moeda não foi encontrada!");
        }
    }

}
