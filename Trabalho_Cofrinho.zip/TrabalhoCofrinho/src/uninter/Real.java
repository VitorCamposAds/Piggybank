package uninter;

public class Real extends Moeda {
	
	// Construtor da classe Real
	public Real(double valorInicial) {
		// Chama o construtor da classe pai (Moeda) e define o valor inicial da moeda em Real
		this.valor = valorInicial;
	}

	// Implementação do método info() da classe Moeda
	@Override
	public void info() {
		// Imprime uma mensagem com o tipo da moeda (Real) e o seu valor
		System.out.println("Real - " + valor);
	}

	// Implementação do método converter() da classe Moeda
	@Override
	public double converter() {
		// Retorna o valor da moeda em Real (não realiza nenhuma conversão)
		return this.valor;
	}
	
	// Implementação do método equals() da classe Object para comparar moedas do tipo Real
	@Override
	public boolean equals(Object objeto) {
	    // Verifica se o objeto passado é uma instância da classe Real
	    if (this.getClass() != objeto.getClass()) {
	        return false;
	    }
	    
	    // Faz o cast do objeto para o tipo Real
	    Real objetoDeReal = (Real) objeto;
	    
	    // Compara o valor das moedas para determinar se são iguais
	    if (this.valor != objetoDeReal.valor){
	    	return false;
	    }

	    // Retorna true se as moedas tiverem o mesmo valor
	    return true;
	}
}
