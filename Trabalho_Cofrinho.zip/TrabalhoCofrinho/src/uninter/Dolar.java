package uninter;

public class Dolar extends Moeda {
	
	// Construtor da classe Dolar
	public Dolar(double valorInicial) {
		// Chama o construtor da classe pai (Moeda) e define o valor inicial da moeda em dólar
		this.valor = valorInicial;
	}

	// Implementação do método info() da classe Moeda
	@Override
	public void info() {
		// Imprime uma mensagem com o tipo da moeda (Dólar) e o seu valor
		System.out.println("Dólar - " + valor);
	}

	// Implementação do método converter() da classe Moeda
	@Override
	public double converter() {
		// Converte o valor da moeda em dólar para Real utilizando a cotação 4.88 (valor fictício)
		return this.valor * 4.88;
	}
	
	// Implementação do método equals() da classe Object para comparar moedas do tipo Dolar
	@Override
	public boolean equals(Object objeto) {
	    // Verifica se o objeto passado é uma instância da classe Dolar
	    if (this.getClass() != objeto.getClass()) {
	        return false;
	    }
	    
	    // Faz o cast do objeto para o tipo Dolar
	    Dolar objetoDeDolar = (Dolar) objeto;
	    
	    // Compara o valor das moedas para determinar se são iguais
	    if (this.valor != objetoDeDolar.valor){
	    	return false;
	    }

	    // Retorna true se as moedas tiverem o mesmo valor
	    return true;
	}

}
